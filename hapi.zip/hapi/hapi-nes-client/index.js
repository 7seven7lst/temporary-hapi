var Nes = require('nes');

var client = new Nes.Client('ws://localhost:3001');
client.connect({ auth: { headers: { authorization: 'Basic am9objpzZWNyZXQ=' } } }, function (err) {

    client.request('hello', function (err, payload) {   // Can also request '/h'

        // payload -> 'Hello John Doe'
        console.log("payload is >>>>>", payload);
    });
});
